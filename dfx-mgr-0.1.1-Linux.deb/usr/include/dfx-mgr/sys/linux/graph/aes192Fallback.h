

extern int softgAES192(void** inData, int* inDataSize, void** outData, int* outDataSize);
