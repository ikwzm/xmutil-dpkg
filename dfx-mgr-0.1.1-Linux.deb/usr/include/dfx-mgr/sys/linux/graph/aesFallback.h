

extern int softgAES128(void** inData, int* inDataSize, void** outData, int* outDataSize);
