/*
 * Copyright (c) 2021, Xilinx Inc. and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: MIT
 */
extern int compare(int counts, uint32_t *address, uint32_t *reference);
extern void printhex(uint32_t* data, uint32_t len);
